package cn.sybc.servlet;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sybc.dao.DishesDao;
import cn.sybc.dao.DishesTypeDao;
import cn.sybc.domain.Dishes;
import cn.sybc.domain.DishesType;
import cn.sybc.tool.FileTool;

@WebServlet("/DishesServlet")
public class DishesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DishesServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		
		String method=request.getParameter("method");
		switch(method) {
		case "findAll":findAll(request,response);
		case "save":save(request,response);
		case "show":show(request,response);
		case "showupdate":showupdate(request,response);
		case "update":update(request,response);
		case "del":del(request,response);
		break;
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
    private void findAll(HttpServletRequest request, HttpServletResponse response) {
		try {
			DishesDao disDao=new DishesDao();
			DishesTypeDao typeDao=new DishesTypeDao();
			List<Dishes> dislist=disDao.findDishes();
			List<DishesType> typeList=typeDao.findDishesType();
			request.setAttribute("dislist", dislist);
			request.setAttribute("typeList", typeList);
			request.getRequestDispatcher("./jsp/admin/pages/dishes-list.jsp").forward(request,response);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
    private void save(HttpServletRequest request, HttpServletResponse response) {
		try {
			DishesTypeDao typeDao=new DishesTypeDao();
			List<DishesType> typelist=typeDao.findDishesType();
			request.setAttribute("typelist", typelist);
			request.getRequestDispatcher("./jsp/admin/pages/dishes-add.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}	
	}
	private void show(HttpServletRequest request, HttpServletResponse response) {
		try {
			DishesDao dishesDao=new DishesDao();
			Dishes dishes=new Dishes();
			FileTool filetool=new FileTool();
		    Map<String,Object>map= filetool.originalfileUpload(request);
		    for(String key:map.keySet()) {
		    	switch(key) {
		    	case "dishesName":
		    		dishes.setDishesName(map.get(key).toString());break;
		    	case "material":
		    		dishes.setMaterial(map.get(key).toString());break;
		    	case "marketPrice":
		    		dishes.setMarketPrice(Double.parseDouble(map.get(key).toString()));break;
		    	case "vipPrice":
		    		dishes.setVipPrice(Double.parseDouble(map.get(key).toString()));break;
		    	case "dishesTypeId":
		    		dishes.setDishesTypeId(Integer.parseInt(map.get(key).toString()));break;
		    	case "pic":
		    		dishes.setPic(map.get(key).toString());break;
		    	case "desc":
		    		dishes.setDesc(map.get(key).toString());break;
		    	}
		    }
		    dishesDao.saveDishes(dishes);
		    response.sendRedirect("./DishesServlet?method=findAll");
		}catch(Exception e) {
			e.printStackTrace();
		}		
	}	
	private void showupdate(HttpServletRequest request, HttpServletResponse response) {
		try {
			int id=Integer.parseInt(request.getParameter("id"));
			DishesDao dishesDao=new DishesDao();
			Dishes dishes= dishesDao.getDishesById(id);
			DishesTypeDao typeDao=new DishesTypeDao();
			List<DishesType> typelist=typeDao.findDishesType();
			request.setAttribute("typelist", typelist);
			request.setAttribute("dishes", dishes);
			request.getRequestDispatcher("./jsp/admin/pages/dishes-update.jsp").forward(request, response);;
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void update(HttpServletRequest request, HttpServletResponse response) {
		try {
			DishesDao dishesDao=new DishesDao();
			Dishes dishes=new Dishes();
			String rpic="";
			FileTool filetool=new FileTool();
		    Map<String,Object>map= filetool.originalfileUpload(request);
		    for(String key:map.keySet()) {
		    	//System.out.println(key+"\t"+map.get(key).toString());
				switch(key) {
				case "id":
					dishes.setId(Integer.parseInt(map.get(key).toString()));break;
				case "dishesName":
		    		dishes.setDishesName(map.get(key).toString());break;
		    	case "material":
		    		dishes.setMaterial(map.get(key).toString());break;
		    	case "marketPrice":
		    		dishes.setMarketPrice(Double.parseDouble(map.get(key).toString()));break;
		    	case "vipPrice":
		    		dishes.setVipPrice(Double.parseDouble(map.get(key).toString()));break;
		    	case "dishesTypeId":
		    		dishes.setDishesTypeId(Integer.parseInt(map.get(key).toString()));break;
		    	case "pic":
		    		dishes.setPic(map.get(key).toString());break;
		    	case "desc":
		    		dishes.setDesc(map.get(key).toString());break;
		    	case "rpic":
		    		rpic=map.get(key).toString();break;
				}
			}
		    if(dishes.getPic()==null||dishes.getPic()=="") {
				dishes.setPic(rpic);
			}
			dishesDao.update(dishes);
			response.sendRedirect("./DishesServlet?method=findAll");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}	
	private void del(HttpServletRequest request, HttpServletResponse response) {
		try {
			String ids=request.getParameter("ids").toString();
			String id[]=ids.split(",");
			DishesDao dishesDao=new DishesDao();
			for(int i=0;i<id.length;i++) {
				dishesDao.delDishes(Integer.parseInt(id[i]));
			}
			response.sendRedirect("./DishesServlet?method=findAll");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
