package cn.sybc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sybc.dao.DishesDao;
import cn.sybc.dao.DishesTypeDao;
import cn.sybc.dao.NotictDao;
import cn.sybc.dao.OrdersDao;
import cn.sybc.domain.Dishes;
import cn.sybc.domain.DishesType;
import cn.sybc.domain.Notice;
import cn.sybc.domain.Orders;

/**
 * Servlet implementation class DishesWebServlet
 */
@WebServlet("/DishesWebServlet")
public class DishesWebServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DishesWebServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		String method=request.getParameter("method");
		switch(method) {
		case "findAll":findAll(request,response);break;
		//case "save":saveCar(request,response);break;
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	private void findAll(HttpServletRequest request, HttpServletResponse response) {
		try {
			DishesDao disDao=new DishesDao();
			DishesTypeDao typeDao=new DishesTypeDao();
			List<Dishes> dishelist=disDao.findDishes();
			List<DishesType> typelist=typeDao.findDishesType();
			
			NotictDao notiDao=new NotictDao();
			List<Notice> notices=notiDao.getNotict();
			
			OrdersDao orderDao=new OrdersDao();
			List<Orders> orderList=orderDao.getOrdersRanking();
			
			request.setAttribute("disheslist", dishelist);
			request.setAttribute("typelist", typelist);
			request.setAttribute("notices", notices);
			request.setAttribute("orderList",orderList);
			request.getRequestDispatcher("./jsp/web/pages/main.jsp").forward(request, response);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
