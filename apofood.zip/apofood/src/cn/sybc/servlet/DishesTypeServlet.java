package cn.sybc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sybc.dao.DishesTypeDao;
import cn.sybc.domain.DishesType;

@WebServlet("/DishesTypeServlet")
public class DishesTypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DishesTypeServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		
		String method=request.getParameter("method");
		switch(method) {
		case "findAll":findAll(request,response);break;
		case "save":save(request,response);break;
		case "update":update(request,response);break;
		case "del":del(request,response);break;
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
   public void findAll(HttpServletRequest request, HttpServletResponse response) {
	   try {
		   DishesTypeDao typedao=new DishesTypeDao();
		   List<DishesType> typelist=typedao.findDishesType();
		   request.setAttribute("typelist", typelist);
		   request.getRequestDispatcher("./jsp/admin/pages/dishestype-list.jsp").forward(request, response);
		   
	   }catch(Exception e) {
		   e.printStackTrace();
	   }
   }
   public void save(HttpServletRequest request, HttpServletResponse response) {
	   try {
		   String typeName=request.getParameter("typeName");
		   DishesTypeDao typedao=new DishesTypeDao();
		   typedao.saveDishesType(typeName);
		   response.sendRedirect("./DishesTypeServlet?method=findAll");
	   }catch(Exception e) {
		   e.printStackTrace();
	   }
   }
   public void update(HttpServletRequest request, HttpServletResponse response) {
	   try {
		   String typeName=request.getParameter("typeName");
		   Integer id=Integer.parseInt(request.getParameter("id"));
		   DishesTypeDao typedao=new DishesTypeDao();
		   typedao.updateDishesType(id, typeName);
		   response.sendRedirect("./DishesTypeServlet?method=findAll");
	   }catch(Exception e) {
		   e.printStackTrace();
	   }
   }
   public void del(HttpServletRequest request, HttpServletResponse response) {
	   try { 
		   String ids=request.getParameter("ids").toString();
		   String id[]=ids.split(",");
		   DishesTypeDao typedao=new DishesTypeDao();
		   for(int i=0;i<id.length;i++) {
			   typedao.delDishesType(Integer.parseInt(id[i]));
		   }
		   response.sendRedirect("./DishesTypeServlet?method=findAll");
	   }catch(Exception e) {
		   e.printStackTrace();
	   }
   }
}
