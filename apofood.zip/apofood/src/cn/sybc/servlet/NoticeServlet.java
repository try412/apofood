package cn.sybc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sybc.dao.NotictDao;
import cn.sybc.domain.Notice;

@WebServlet("/NoticeServlet")
public class NoticeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public NoticeServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		
		String method=request.getParameter("method");
		switch(method) {
		case "findAll":findAll(request,response);break;
		case "save":save(request,response);break;
		case "del":del(request,response);break;
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
     private void findAll(HttpServletRequest request, HttpServletResponse response) {
    	 try{
    		 NotictDao noticeDao=new NotictDao();
    		 List<Notice> notice=noticeDao.findNotict();
    		 request.setAttribute("notice", notice);
 			 request.getRequestDispatcher("./jsp/admin/pages/notice-list.jsp").forward(request, response);
 		}catch(Exception e) {
 			e.printStackTrace();
 		}
	}
     private void save(HttpServletRequest request, HttpServletResponse response) { 
    	 try{
    		 String title=request.getParameter("title");
    		 String content=request.getParameter("content");
    		 NotictDao noticeDao=new NotictDao();
 		     noticeDao.save(title,content);
 		     response.sendRedirect("./NoticeServlet?method=findAll");
 		}catch(Exception e) {
 			e.printStackTrace();
 		}		
 	}
 	private void del(HttpServletRequest request, HttpServletResponse response) {
 		 try{
 			 String ids=request.getParameter("ids");
 			 String id[]=ids.split(",");
    		 NotictDao noticeDao=new NotictDao();
    		 for(int i=0;i<id.length;i++) 
    		 {
    			 noticeDao.del(Integer.parseInt(id[i]));
    		 }
 		     response.sendRedirect("./NoticeServlet?method=findAll");
 		}catch(Exception e) {
 			e.printStackTrace();
 		}			
	}
}
