 package cn.sybc.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.PortableServer.RequestProcessingPolicyOperations;

import cn.sybc.dao.OrdersDao;
import cn.sybc.domain.Orders;

@WebServlet("/OrdersServlet")
public class OrdersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public OrdersServlet() {
        super();     
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		
		String method=request.getParameter("method");
		switch(method) {
		case "findAll":findAll(request,response);break;
		case "getorder":getorder(request,response);break;
		case "updataorderStatus":updataorderStatus(request,response);break;
		case "sale":sale(request,response);break;
		}
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
    private void findAll(HttpServletRequest request, HttpServletResponse response) {
		try{
			OrdersDao orderDao=new OrdersDao();
			List<Orders> orders=new ArrayList<Orders>();
			orders=orderDao.findOrders(null, null, null);
        	request.setAttribute("orders",orders);
			request.getRequestDispatcher("./jsp/admin/pages/orders-list.jsp").forward(request, response);;
		}catch(Exception e) {
			e.printStackTrace();
		}
	}private void getorder(HttpServletRequest request, HttpServletResponse response) {
		try {
			OrdersDao orderDao=new OrdersDao();
			List<Orders> orders=new ArrayList<Orders>();
			
			String userName=request.getParameter("userName");
			String dishesName=request.getParameter("dishesName");
			String orderTime=request.getParameter("orderTime");
			
			orders=orderDao.findOrders(userName,dishesName,orderTime);
			
			request.setAttribute("userName", userName);
			request.setAttribute("dishesName", dishesName);
			request.setAttribute("orderTime", orderTime);			
        	request.setAttribute("orders",orders);
			request.getRequestDispatcher("./jsp/admin/pages/orders-list.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}	
	}
	private void updataorderStatus(HttpServletRequest request, HttpServletResponse response) {
		try{
			int id=Integer.parseInt(request.getParameter("id"));
			int status=Integer.parseInt(request.getParameter("status"));
			OrdersDao orderDao=new OrdersDao();
            orderDao.updatastatus(id,status);
			response.sendRedirect("./OrdersServlet?method=findAll");
		}catch(Exception e) {
			e.printStackTrace();
		}	
	}
	private void sale(HttpServletRequest request, HttpServletResponse response) {
		try {
			String orderTime=request.getParameter("orderTime");
			double money=0;
			OrdersDao orderDao=new OrdersDao();
			List<Orders> orders=orderDao.getOrdersCount(orderTime);
			for(Orders order:orders) {
				money+=order.getNumPrice();
			}
			request.setAttribute("orderTime",orderTime);
			request.setAttribute("orders",orders);
			request.setAttribute("money",money);
			request.getRequestDispatcher("./jsp/admin/pages/sales-count.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
