package cn.sybc.servlet;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sybc.dao.UserDao;
import cn.sybc.domain.Users;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UserServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		String method=request.getParameter("method");
		switch(method) {
		case "registe":registe(request,response);break;
		case "login":login(request,response);break;
		case "logout":logout(request,response);break;
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	private void registe(HttpServletRequest request, HttpServletResponse response) {
		try {	
			Users user=new Users();
			user.setLoginName(request.getParameter("loginName"));
			user.setPassword(request.getParameter("password"));
			user.setUserName(request.getParameter("userName"));
			user.setSex(Integer.parseInt(request.getParameter("sex")));
			user.setAge(Integer.parseInt(request.getParameter("age")));
			user.setIdCard(request.getParameter("idCard"));
			user.setAddress(request.getParameter("address"));
			user.setPhone(request.getParameter("phone"));
			user.setEmail(request.getParameter("email"));
			UserDao userDao=new UserDao();
			String message="";
			int n=userDao.register(user);
			if(n>0) {
				response.getWriter().print("<script>alert('注册成功，请到登录页面');"
			    +"window.location.href='./jsp/web/pages/login.jsp'</script>");
			}else {
				response.getWriter().print("<script>alert('注册失败，请重新注册');"
						+"window.location.href='./jsp/web/pages/registered.jsp'</script>");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}	
	}
	private void login(HttpServletRequest request, HttpServletResponse response) {
	 try {
		String loginName=request.getParameter("loginName");
		String password=request.getParameter("password");
		UserDao userDao=new UserDao();
		Users user=userDao.getLogin(loginName, password);
		String message="";
		if(user.getLoginName()!=null) {
			request.getSession().setAttribute("user", user);
			response.sendRedirect("./DishesWebServlet?method=findAll");
			//request.getRequestDispatcher("./jsp/web/pages/main.jsp").forward(request, response);;
		}else{
			request.setAttribute("message", "用户名或密码错误！");
			request.getRequestDispatcher("./jsp/web/pages/login.jsp").forward(request, response);
		}
	 }catch (Exception e) {
		e.printStackTrace();
	}	
	}
	private void logout(HttpServletRequest request, HttpServletResponse response) {
		try {
    		Enumeration em=request.getSession().getAttributeNames();
    		while(em.hasMoreElements()) {
    			request.getSession().removeAttribute(em.nextElement().toString());
    		}
    		request.getRequestDispatcher("./jsp/web/pages/login.jsp").forward(request, response);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
	}
}
