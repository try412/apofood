package cn.sybc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sybc.dao.CarDao;
import cn.sybc.dao.OrdersDao;
import cn.sybc.domain.ShoppingCar;
import cn.sybc.domain.Users;

@WebServlet("/CarServlet")
public class CarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public CarServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		
		String method=request.getParameter("method");
		switch(method) {
		case "save":shopping(request,response);break;
		case "findAll":findAll(request,response);break;
		case "delbyid":delbyid(request,response);break;
		case "del":del(request,response);break;
		case "subAll":subAll(request,response);break;
		}	 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	private void shopping(HttpServletRequest request, HttpServletResponse response) {
     try {
    	 int n=0;
    	 String dishesName=request.getParameter("dishesName");
    	 double price=Double.parseDouble(request.getParameter("price").toString());
    	 Users user=(Users) request.getSession().getAttribute("user");
    	 
    	 ShoppingCar car=new ShoppingCar();
    	 CarDao carDao=new CarDao();
    	 car=carDao.getShopping(dishesName, user.getId());
    	 if(car.getId()>0) {
    		 n=carDao.updateCar(car.getNumber()+1, car.getId());
    	 }else {  
    		 car.setDishesName(dishesName);
    	     car.setNumber(1); 
    	     car.setPrice(price);
    	     car.setUserId(user.getId());
    	     n=carDao.savecar(car);
    	 }
    	 if(n>0) {
    		 response.getWriter().print("<script>alert('购买商品成功');window.location.href='./DishesWebServlet?method=findAll'</script>");
    	 }
    	 else {
    		 response.getWriter().print("<script>alert('购买商品失败!');window.location.href='./DishesWebServlet?method=findAll'</script>"); 
    	 }
     }catch (Exception e) {
		e.printStackTrace();
	  }
	}
	private void findAll(HttpServletRequest request, HttpServletResponse response) {
		try {
			Users user=(Users)request.getSession().getAttribute("user");
			double money=0;
			int num=0;
			CarDao carDao=new CarDao();
			List<ShoppingCar> list=carDao.findAll(user.getId());
			for(ShoppingCar car:list) {
				money+=car.getPrice()*car.getNumber();
				num+=car.getNumber();
			}
			request.setAttribute("carList", list);
			request.setAttribute("money", money);
			request.setAttribute("num", num);
			request.getRequestDispatcher("./jsp/web/pages/shoppingCart.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void delbyid(HttpServletRequest request, HttpServletResponse response) {
		try {
			int id=Integer.parseInt(request.getParameter("id"));
			CarDao carDao=new CarDao();
			carDao.del(id);
			response.sendRedirect("./CarServlet?method=findAll");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	private void del(HttpServletRequest request, HttpServletResponse response) {
		try {
			String ids=request.getParameter("ids");
			String id[]=ids.split(",");
			CarDao carDao=new CarDao();
			for(int i=0;i<id.length;i++) {
				carDao.del(Integer.parseInt(id[i]));
			}
			response.sendRedirect("./CarServlet?method=findAll");	
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void subAll(HttpServletRequest request, HttpServletResponse response) {
		try {
			Users user=(Users)request.getSession().getAttribute("user");
			String ids=request.getParameter("ids");
			String id[]=ids.split(",");
			CarDao carDao=new CarDao();
			List<ShoppingCar> list=carDao.show(user.getId(),id);
			
			OrdersDao orderDao=new OrdersDao();
			int n=orderDao.saveAll(list);
			if(n==list.size()) {
				for(ShoppingCar car:list) {
					carDao.del(car.getId());
				}
			}
			response.sendRedirect("./CarServlet?method=findAll");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
