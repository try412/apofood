package cn.sybc.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sybc.dao.AdminInfoDao;
import cn.sybc.domain.AdminInfo;

@WebServlet("/AdminInfoServlet")
public class AdminInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AdminInfoServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8"); 
		response.setHeader("Content-Type", "text/html;charset=utf-8");
		
		String method=request.getParameter("method");
		switch(method) {
		case "login":login(request,response);break;
		case "dele":dele(request,response);break;
		case "update":update(request,response);break;
		default :break;
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
    public void login(HttpServletRequest request, HttpServletResponse response) {
    	String loginname=request.getParameter("loginname").toString();
    	String password=request.getParameter("password").toString();
    	AdminInfoDao admininfo=new AdminInfoDao();
    	try {
    		AdminInfo admin=admininfo.login(loginname, password);
    		if(admin.getLoginName()!=null) {
    			request.getSession().setAttribute("adminInfo", admin);
    			request.setAttribute("me","");
    			request.getRequestDispatcher("./jsp/admin/pages/main.jsp").forward(request, response);
    		}
    		else {
    			request.setAttribute("me", "用户名或密码输入错误");
    			request.setAttribute("loginName",loginname);
    			request.setAttribute("password",password);
    			request.getRequestDispatcher("./jsp/admin/pages/login.jsp").forward(request, response);
    		}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    }
    public void dele(HttpServletRequest request, HttpServletResponse response) {
    	try {
    		Enumeration em=request.getSession().getAttributeNames();
    		while(em.hasMoreElements()) {
    			request.getSession().removeAttribute(em.nextElement().toString());
    		}
    		request.getRequestDispatcher("/jsp/admin/pages/login.jsp").forward(request, response);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    }
	private void update(HttpServletRequest request, HttpServletResponse response) {
		try {
    		String password=request.getParameter("password");
    		String npassword=request.getParameter("npassword");
    		String rpassword=request.getParameter("rpassword");
    		String message="";
    		AdminInfo admin=(AdminInfo)request.getSession().getAttribute("adminInfo");
    		if(password.equals(admin.getPassword())) {
    			if(npassword.equals(rpassword)) {
    				AdminInfoDao adminDao=new AdminInfoDao();
    				int n=adminDao.update(admin.getId(), rpassword);
    				if(n>0) {
    					PrintWriter pw=response.getWriter();
    					pw.write("<script>alert('密码修改成功，请重新登录');"+
    					"window.location.href='./AdminInfoServlet?method=dele'</script>");
    					return;
    				}else {
    					message="修改失败";
    				}
    			}else {
    				message="两次新密码输入不一样";
    			}
    		}else {
    			message="原始密码输入错误";
    		}	
    		request.setAttribute("message", message);
			request.getRequestDispatcher("./jsp/admin/pages/change-password.jsp").forward(request, response);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
		
	}
}
