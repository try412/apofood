package cn.sybc.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import cn.sybc.domain.DishesType;

public class DishesTypeDao {
  private Connection conn;
  private PreparedStatement psmt;
  private ResultSet result;
  public List<DishesType> findDishesType(){
	  List<DishesType> list=new ArrayList<DishesType>();
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="select * from dishestype where status=1";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  result=psmt.executeQuery();
		   list=new ArrayList<DishesType>();
		   while(result.next()) {
			   if(result.getRow()>0) {
				   DishesType type=new DishesType();
				   type.setId(result.getInt("id"));
				   type.setStatus(result.getInt("status"));
				   type.setTypeName(result.getString("typeName"));
				   list.add(type);
			   }
		   }
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return list;
  }
  public int saveDishesType(String typeName) {
	  int n=0;
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="insert into dishestype(typeName,`status`) values(?,1)";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  psmt.setString(1, typeName);
		  n=psmt.executeUpdate();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return n;
  }
 public int updateDishesType(Integer id, String typeName) {
	  int n=0;
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="update dishestype set typeName=? where id=?";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  psmt.setString(1, typeName);
		  psmt.setInt(2, id);
		  n=psmt.executeUpdate();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return n;
 }
public int delDishesType(int id) {
	 int n=0;
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="update dishestype set `status`=0 where id=?";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  psmt.setInt(1, id);
		  n=psmt.executeUpdate();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return n;
}
}
