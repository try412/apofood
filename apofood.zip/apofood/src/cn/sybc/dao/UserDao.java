package cn.sybc.dao;

import java.sql.ResultSet;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import cn.sybc.domain.Users;

public class UserDao {
  static  Connection conn;
  static PreparedStatement psmt;
  static ResultSet result;
  public int register(Users user) {
	  int n=0;
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="insert into users(loginName,`password`,userName,sex,age,idCard,address,phone,email) values(?,?,?,?,?,?,?,?,?)";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  psmt.setString(1, user.getLoginName());
		  psmt.setString(2, user.getPassword());
		  psmt.setString(3, user.getUserName());
		  psmt.setInt(4, user.getSex());
		  psmt.setInt(5, user.getAge());
		  psmt.setString(6, user.getIdCard());
		  psmt.setString(7, user.getAddress());
		  psmt.setString(8, user.getPhone());
		  psmt.setString(9, user.getEmail());
		  n=psmt.executeUpdate();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return n;
  }
  public Users getLogin(String loginName,String password) {
	  Users user=new Users();
	  try {
		conn=(Connection) DBHelper.getConn();
		String sql="SELECT * FROM users where loginName=? and `password`=?";
		psmt=(PreparedStatement) conn.prepareStatement(sql);
		psmt.setString(1, loginName);
		psmt.setString(2, password);
		result=psmt.executeQuery();
		while(result.next()) {
			if(result.getRow()>0) {
				user.setId(result.getInt("id"));
				user.setLoginName(result.getString("loginName"));
				user.setPassword(result.getString("password"));
				user.setUserName(result.getString("userName"));
				user.setSex(result.getInt("sex"));
				user.setAge(result.getInt("age"));
				user.setIdCard(result.getString("idCard"));
				user.setAddress(result.getString("address"));
				user.setPhone(result.getString("phone"));
				user.setEmail(result.getString("email"));
			}
		}
	  }catch (Exception e) {
		e.printStackTrace();
	}
	  return user;
  }
}
