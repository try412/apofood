package cn.sybc.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import cn.sybc.domain.ShoppingCar;

public class CarDao {
	static  Connection conn;
	static PreparedStatement psmt;
	static ResultSet result;
	public ShoppingCar getShopping(String dishesName,int userId) {
		ShoppingCar car=new ShoppingCar();
		try {
			conn=(Connection) DBHelper.getConn();
			String sql="select * from shoppingcar where dishesName=? and userId=?";
			psmt=(PreparedStatement) conn.prepareStatement(sql);
			psmt.setString(1, dishesName);
			psmt.setInt(2, userId);
			result=psmt.executeQuery();
			while(result.next()) {
				if(result.getRow()>0) {
					car.setId(result.getInt("id"));
					car.setDishesName(result.getString("dishesName"));
					car.setNumber(result.getInt("number"));
					car.setPrice(result.getDouble("price"));
					car.setShoppingTime(result.getDate("shoppingTime"));
					car.setUserId(result.getInt("userId"));
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return car;
	}
	public int updateCar(int number,int id) {
		int n=0;
		try {
			conn=(Connection) DBHelper.getConn();
			String sql="update shoppingcar set number=? where id=?";
			psmt=(PreparedStatement) conn.prepareStatement(sql);
			psmt.setInt(1, number);
			psmt.setInt(2, id);
			n=psmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return n;
	}
	public int savecar(ShoppingCar car) {
		int n=0;
		try {
			conn=(Connection) DBHelper.getConn();
			String sql="insert into shoppingcar(userId,dishesName,number,price,shoppingTime) values(?,?,?,?,now())";
			psmt=(PreparedStatement) conn.prepareStatement(sql);
			psmt.setInt(1, car.getUserId());
			psmt.setString(2, car.getDishesName());
			psmt.setInt(3, car.getNumber());
			psmt.setDouble(4,car.getPrice());
			n=psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return n;
	}
	public List<ShoppingCar> findAll(int userid) {
		List<ShoppingCar> list=new ArrayList<ShoppingCar>();
		try {
			conn=(Connection) DBHelper.getConn();
			String sql="select * from shoppingcar where userId=?";
			psmt=(PreparedStatement) conn.prepareStatement(sql);
			psmt.setInt(1,userid);
			result=psmt.executeQuery();
			while(result.next()){
				if(result.getRow()>0) {
					ShoppingCar car=new ShoppingCar();
					car.setId(result.getInt("id"));
					car.setDishesName(result.getString("dishesName"));
					car.setNumber(result.getInt("number"));
					car.setPrice(result.getDouble("price"));
					car.setShoppingTime(result.getDate("shoppingTime"));
					car.setUserId(result.getInt("userId"));	
					list.add(car);
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public int del(int id) {
	  int n=0;
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="delete  from shoppingcar where id=?";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  psmt.setInt(1, id);
		  n=psmt.executeUpdate();
	  }catch (Exception e) {
		e.printStackTrace();
	 }	
	  return n;
	}
	public  List<ShoppingCar> show(int userId,String[] ids) {
		 List<ShoppingCar> list=new ArrayList<ShoppingCar>();
		  try {
			  conn=(Connection) DBHelper.getConn();
			  String sql="select * from shoppingcar where userId=? and id in(";
			  for(int i=0;i<ids.length;i++) {
				 sql+=ids[i]+",";
			  }
			  sql=sql.substring(0,sql.length()-1);
			  sql+=")";
			  psmt=(PreparedStatement) conn.prepareStatement(sql);
			  psmt.setInt(1, userId);
			  result=psmt.executeQuery();
			  while(result.next()){
					if(result.getRow()>0) {
						ShoppingCar car=new ShoppingCar();
						car.setId(result.getInt("id"));
						car.setDishesName(result.getString("dishesName"));
						car.setNumber(result.getInt("number"));
						car.setPrice(result.getDouble("price"));
						car.setShoppingTime(result.getDate("shoppingTime"));
						car.setUserId(result.getInt("userId"));	
						list.add(car);
					}
				}
		  }catch (Exception e) {
			e.printStackTrace();
		 }finally {
			 DBHelper.close(conn, psmt, null);
		 }
		  return list;
	}
}
