		package cn.sybc.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHelper {
	
	private static String driver;//驱动
    private static String url;//mysql服务器地址
    private static String username;//用户名
    private static String password;//密码
    
    static {
        try {
            //获取数据库连接驱动名字
            driver ="com.mysql.jdbc.Driver";
            //获取数据库连接地址
            url ="jdbc:mysql://127.0.0.1:3306/aposi?characterEncoding=utf-8";
            //获取数据库连接用户名
            username ="root";
            //获取数据库连接密码
            password ="root";
            if(driver != null && url != null
                    && username != null && password != null){
                //加载驱动
                Class.forName(driver);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 获取连接对象
     * @return Connection连接对象
     */
    public static Connection getConn(){
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url,username,password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * 关闭连接（Connection连接对象必须在最后关闭）
     * @param conn Connection连接对象
     * @param st 编译执行对象
     * @param rs 结果集
     */
    public static void close(Connection conn, Statement st, ResultSet rs){
        try {
            if(rs != null){
                rs.close();
            }
            if(st != null){
                st.close();
            }
            if(conn != null){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
