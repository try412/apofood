package cn.sybc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import cn.sybc.domain.Dishes;

public class DishesDao {
   private Connection conn;
   private PreparedStatement psmt;
   private ResultSet result;
   public List<Dishes> findDishes(){
	   List<Dishes> list=new ArrayList<Dishes>();
	   try {
		 conn=(Connection) DBHelper.getConn();
		 String sql="select * from dishes where `status`=1";
		 psmt=(PreparedStatement) conn.prepareStatement(sql);
		 result=psmt.executeQuery();
		 while(result.next()) {
			 if(result.getRow()>0) {
				Dishes dis=new Dishes();
				dis.setId(result.getInt("id"));
				dis.setDishesName(result.getString("dishesName"));
				dis.setMaterial(result.getString("material"));
				dis.setMarketPrice(result.getInt("marketPrice"));
				dis.setVipPrice(result.getInt("vipPrice"));
				dis.setDishesTypeId(result.getInt("dishesTypeId"));
				dis.setPic(result.getString("pic"));
				dis.setDesc(result.getString("desc"));
				dis.setStatus(result.getInt("status"));
				list.add(dis);
			 }
		 }
	   }catch(Exception e) {
		   e.printStackTrace();
	   }finally {
		   DBHelper.close(conn, psmt, null);
	   }
	   return list;
   }
    public int saveDishes(Dishes dishes) throws SQLException {
    	int n=0;
 	   try {
 		   conn=(Connection) DBHelper.getConn();
 		   String sql="insert into dishes(dishesName,material,marketPrice,vipPrice,dishesTypeId,pic,`desc`,`status`)"+"values(?,?,?,?,?,?,?,1);";
 		   psmt =(PreparedStatement) conn.prepareStatement(sql);
 		   psmt.setString(1, dishes.getDishesName());
 		   psmt.setString(2, dishes.getMaterial());
 		   psmt.setDouble(3, dishes.getMarketPrice());
 		   psmt.setDouble(4, dishes.getVipPrice());
 		   psmt.setInt(5, dishes.getDishesTypeId());
 		   psmt.setString(6, dishes.getPic());
 		   psmt.setString(7, dishes.getDesc());
 		   n=psmt.executeUpdate();
 	   }catch(Exception e) {
 		   e.printStackTrace();
 	   }
 	   return n;
   }
	public Dishes getDishesById(int id) {
		 Dishes dis=new Dishes();
		   try {
			 conn=(Connection) DBHelper.getConn();
			 String sql="select * from dishes where id=?";
			 psmt=(PreparedStatement) conn.prepareStatement(sql);
			 psmt.setInt(1, id);
			 result=psmt.executeQuery();
			 while(result.next()) {
				 if(result.getRow()>0) {
					dis.setId(result.getInt("id"));
					dis.setDishesName(result.getString("dishesName"));
					dis.setMaterial(result.getString("material"));
					dis.setMarketPrice(result.getInt("marketPrice"));
					dis.setVipPrice(result.getInt("vipPrice"));
					dis.setDishesTypeId(result.getInt("dishesTypeId"));
					dis.setPic(result.getString("pic"));
					dis.setDesc(result.getString("desc"));
					dis.setStatus(result.getInt("status"));
				 }
			 }
		   }catch(Exception e) {
			   e.printStackTrace();
		   }finally {
			   DBHelper.close(conn, psmt, null);
		   }
		   return dis;
	}
	public int update(Dishes dishes) throws SQLException {
		int n=0;
	 	   try {
	 		   conn=(Connection) DBHelper.getConn();
	 		   String sql="update dishes set dishesName=?,material=?,marketPrice=?,vipPrice=?,dishesTypeId=?,pic=?,"+"`desc`=? where id=?";
	 		   psmt =(PreparedStatement) conn.prepareStatement(sql);
	 		   psmt.setString(1, dishes.getDishesName());
	 		   psmt.setString(2, dishes.getMaterial());
	 		   psmt.setDouble(3, dishes.getMarketPrice());
	 		   psmt.setDouble(4, dishes.getVipPrice());
	 		   psmt.setInt(5, dishes.getDishesTypeId());
	 		   psmt.setString(6, dishes.getPic());
	 		   psmt.setString(7, dishes.getDesc());
	 		   psmt.setInt(8, dishes.getId());
	 		   n=psmt.executeUpdate();
	 	   }catch(Exception e) {
	 		   e.printStackTrace();
	 	   }
	 	   return n;
	}
	public int delDishes(int id) throws SQLException{
		int n=0;
		 try {
	 		   conn=(Connection) DBHelper.getConn();
	 		   String sql="update  dishes set `status`=0 where id=?";
	 		   psmt =(PreparedStatement) conn.prepareStatement(sql);
	 		   psmt.setInt(1, id);
	 		   n=psmt.executeUpdate();
	 	   }catch(Exception e) {
	 		   e.printStackTrace();
	 	   }
		return n;
	}
}