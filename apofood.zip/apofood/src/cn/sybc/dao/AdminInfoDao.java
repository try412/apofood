package cn.sybc.dao;

import java.sql.ResultSet;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import cn.sybc.dao.DBHelper;
import cn.sybc.domain.AdminInfo;

public class AdminInfoDao {
  private Connection conn=null;
  private PreparedStatement psmt=null;
  private ResultSet result=null;
  public AdminInfo login(String loginname,String password) {
	  AdminInfo admin=null;
	  try {
      conn=(Connection) DBHelper.getConn();
      String sql="select * from admininfo where loginName=? and password=?";
      psmt =(PreparedStatement) conn.prepareStatement(sql);
      psmt.setString(1, loginname);
      psmt.setString(2, password);
      result=psmt.executeQuery();
      admin=new AdminInfo();
      while(result.next()) {
    	  if(result.getRow()>0) {
    		  admin.setId(result.getInt("id"));
    		  admin.setLoginName(result.getString("loginName"));
    		  admin.setPassword(result.getString("password"));
    		  admin.setAdminName(result.getString("adminName"));
    		  admin.setPic(result.getString("pic"));
    	  }
      }
	  }catch (Exception e) {
		e.printStackTrace();
	}
	  return admin;
  }
public int update(int id, String password) {
	int n=0;
	  try {
		  conn=(Connection) DBHelper.getConn();
	      String sql="update admininfo set `password`=? where id=?";
	      psmt =(PreparedStatement) conn.prepareStatement(sql);
	      psmt.setString(1, password);
	      psmt.setInt(2, id);
	      n=psmt.executeUpdate();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return n;
}
}
