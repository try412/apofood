package cn.sybc.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import cn.sybc.domain.Orders;
import cn.sybc.domain.ShoppingCar;

public class OrdersDao {
  public static Connection conn;
  public static PreparedStatement psmt;
  public static ResultSet result;
  public List<Orders> findOrders(String userName, String dishesName, String orderTime) {
	List<Orders> list=new ArrayList<Orders>();
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="select o.*,u.userName,u.phone,u.address from orders o,users u where u.id=o.userId";
		  if(userName !=null && userName!="") {
			  sql +=" and u.userName like '%"+userName+"%'";
		  }
		  if(dishesName !=null && dishesName!="") {
			  sql +=" and o.dishesName like '%"+dishesName+"%'";
		  }
		  if(orderTime !=null && orderTime!="") {
			  sql +=" and orderTime like '"+orderTime+"%'";
		  }
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  result=psmt.executeQuery();
		  while(result.next()) {
			  if(result.getRow()>0) {
				  Orders order=new Orders();
				  order.setId(result.getInt("id"));
				  order.setDishesName(result.getString("dishesName"));
				  order.setNumber(result.getInt("number"));
				  order.setOrderTime(result.getDate("orderTime"));
				  order.setIsDelivery(result.getInt("isDelivery"));
				  order.setStatus(result.getInt("status"));
				  order.setPrice(result.getDouble("price"));
				  order.setNumPrice(result.getDouble("numPrice"));
				  order.setUserName(result.getString("userName"));
				  order.setPhone(result.getString("phone"));
				  order.setAddress(result.getString("address"));
				  list.add(order);
			  }
		  }
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return list;
}
  public int updatastatus(int id, int status) {
   int n=0;
   try {
	   conn=(Connection) DBHelper.getConn();
	   String sql="update orders set `status`=? where id=?;";
	   psmt=(PreparedStatement) conn.prepareStatement(sql);
	   psmt.setInt(1, status);
	   psmt.setInt(2, id);
	   n=psmt.executeUpdate();
   }catch(Exception e) {
	   e.printStackTrace();
   }
   return n;
  }
  public List<Orders> getOrdersCount(String orderTime){
	  List<Orders>list =new ArrayList<Orders>();
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="select dishesName,number,price,numPrice from orders where orderTime like '"+orderTime+"%'";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  result=psmt.executeQuery();
		  while(result.next()) {
			  if(result.getRow()>0) {
				  Orders order=new Orders();
				  order.setDishesName(result.getString("dishesName"));
				  order.setNumber(result.getInt("number"));
				  order.setPrice(result.getDouble("price"));
				  order.setNumPrice(result.getDouble("numPrice"));
				  list.add(order);
			  }
		  }
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return list;
  }
  public List<Orders> getOrdersRanking(){
	  List<Orders>list =new ArrayList<Orders>();
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="select dishesName,sum(number) number from orders GROUP BY  dishesName ORDER BY number desc LIMIT 0,5;";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  result=psmt.executeQuery();
		  while(result.next()) {
			  if(result.getRow()>0) {
				  Orders order=new Orders();
				  order.setDishesName(result.getString("dishesName"));
				  order.setNumber(result.getInt("number"));
				  list.add(order);
			  }
		  }
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return list;
  }
  public int saveAll(List<ShoppingCar> carlist){
	  int n=0;
	  int s[]=null;
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="insert into orders(userId,dishesName,number,orderTime,isDelivery,`status`,price,numPrice) values(?,?,?,now(),1,1,?,?)";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  for(int i=0;i<carlist.size();i++) {
			  ShoppingCar car=carlist.get(i);
				psmt.setInt(1, car.getUserId());;
				psmt.setString(2, car.getDishesName());
                psmt.setInt(3, car.getNumber());
                psmt.setDouble(4, car.getPrice());
                psmt.setDouble(5, car.getNumber()*car.getPrice());
                psmt.addBatch();
                if((i+1)%carlist.size()==0) {
                	s=psmt.executeBatch();
                	psmt.clearBatch();
                }
		  }
		  for(int i=0;i<s.length;i++) {
			  if(s[i]>0) {
				  n++;
			  }
		  }
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return n;
  }
}
