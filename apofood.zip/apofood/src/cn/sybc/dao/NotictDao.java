package cn.sybc.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import cn.sybc.domain.Notice;

public class NotictDao {
	static Connection conn;
	static PreparedStatement psmt;
	static ResultSet result;
  public List<Notice> findNotict(){
	  List<Notice> list=new ArrayList<Notice>();
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="select * from notice  ORDER BY notTime desc ;";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  result=psmt.executeQuery();
		  while(result.next()) {
			if(result.getRow()>0)  {
				Notice notice=new Notice();
				notice.setId(result.getInt("id"));
				notice.setTitle(result.getString("title"));
				notice.setContent(result.getString("content"));
				notice.setNotTime(result.getDate("notTime"));
				list.add(notice);
			}
		  }
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return list;
  }
  public void save(String title,String content) {
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="insert into notice(title,content,notTime) VALUES(?,?,NOW())"; 
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  psmt.setString(1, title);
		  psmt.setString(2, content);	
		  psmt.executeUpdate();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
  }
  public int  del(int id) {
	  int n=0;
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="delete from notice where id=?"; 
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  psmt.setInt(1,id);
		  n=psmt.executeUpdate();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return n;
  }
  public List<Notice> getNotict(){
	  List<Notice> list=new ArrayList<Notice>();
	  try {
		  conn=(Connection) DBHelper.getConn();
		  String sql="select * from notice  ORDER BY notTime desc limit 0,5";
		  psmt=(PreparedStatement) conn.prepareStatement(sql);
		  result=psmt.executeQuery();
		  while(result.next()) {
			if(result.getRow()>0)  {
				Notice notice=new Notice();
				notice.setId(result.getInt("id"));
				notice.setTitle(result.getString("title"));
				notice.setContent(result.getString("content"));
				notice.setNotTime(result.getDate("notTime"));
				list.add(notice);
			}
		  }
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return list;
  }
}
