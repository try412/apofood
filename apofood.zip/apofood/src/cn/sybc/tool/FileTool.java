package cn.sybc.tool;

import java.io.File;
import java.util.Collection;
import java.util.HashMap; 
import java.util.List;
import java.util.Map; 
import java.util.UUID;
import javax.servlet.annotation.MultipartConfig; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.apache.commons.fileupload.FileItem; 
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class FileTool {
	 public Map<String,Object> originalfileUpload(HttpServletRequest request) throws Exception {       
		 Map<String,Object> map=new HashMap<String,Object>();        
		 String str="";     
		 // 使用fileupload组件完成文件上传,上传的位置       
		 String path = request.getSession().getServletContext().getRealPath("/images/");     
		 //判断该路径是否存在  
		 File file=new File(path);
		 if(!file.exists()){   
			 // 不存在，创建该文件夹          
			 file.mkdirs();
		 }
          // 解析request对象，获取上传文件项     
         DiskFileItemFactory factory = new DiskFileItemFactory(); 
         ServletFileUpload upload = new ServletFileUpload(factory);
         // 解析request       
         List<FileItem> items = upload.parseRequest(request);
         // 遍历       
         for(FileItem item:items){ 
         // 进行判断，当前item对象是否是上传文件项          
	     if(item.isFormField()){      
		   request.setCharacterEncoding("UTF-8");    
	       //将表单中的表单项保存到map集合中            
	       map.put(item.getFieldName(), item.getString("utf-8"));    
	      }
	     else{   
		   if(item.getName()!=null && item.getName()!="") {  
			  // 说明上传文件项               
			  // 获取上传文件的名称            
			  String filename = item.getName();     
			  filename = filename; 
			  // 完成文件上传                 
			  item.write(new File(path,filename));     
			  // 删除临时文件              
			  item.delete();       
              //将上传成功的文件名赋值给str变量                  
			  str="/images/"+filename; 
			  } 	
		   }    
	  }
        map.put("pic",str);    
	    return map;    
	 }
}
